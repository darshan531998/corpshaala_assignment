package com.employapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpolyappApplicationTests {

	@Test
	void contextLoads() {
	}

}
