package com.employapp.domain;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employtb")
public class Employee {
	     @Id
	     @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    private String EMPLOYEENAME;
	    private String Email ;
	    private String DOB;
	    private String AGE;
	    private String SALARY;
	    private String satus;
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getEMPLOYEENAME() {
			return EMPLOYEENAME;
		}
		public void setEMPLOYEENAME(String eMPLOYEENAME) {
			EMPLOYEENAME = eMPLOYEENAME;
		}
		public String getEmail() {
			return Email;
		}
		public void setEmail(String email) {
			Email = email;
		}
		public String getDOB() {
			return DOB;
		}
		public void setDOB(String dOB) {
			DOB = dOB;
		}
		public String getAGE() {
			return AGE;
		}
		public void setAGE(String aGE) {
			AGE = aGE;
		}
		public String getSALARY() {
			return SALARY;
		}
		public void setSALARY(String sALARY) {
			SALARY = sALARY;
		}
		public String getSatus() {
			return satus;
		}
		public void setSatus(String satus) {
			this.satus = satus;
		}
	    
	    
	    
	    
	    
	    

}
